/*
 * pwm.h
 *
 *  Created on: May 3, 2024
 *      Author: Andre
 */

#ifndef INC_PWM_H_
#define INC_PWM_H_

#include "main.h"

void PwmConfig(void);

#endif /* INC_PWM_H_ */
